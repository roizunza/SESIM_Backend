import React, { useEffect, useMemo, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  ArrowRight,
  FileSpreadsheet,
  Gauge,
  Layers,
  MapPin,
  BookOpen,
  Bus,
  TrendingUp,
  Bike,
  ShieldAlert,
  Users,
} from 'lucide-react';
import { EJES_ESTRATEGICOS } from '../lib/ejesEstrategicos';
import { useCatalogo } from '../lib/sesim/useCatalogo';
import { useRevelar, prefiereMenosMovimiento } from '../lib/useRevelar';
import StreetLinesBackground from '../components/plataforma/StreetLinesBackground';
import Contador from '../components/plataforma/Contador';
import EnlaceInstitucional from '../components/plataforma/EnlaceInstitucional';
import SeccionVision from '../components/inicio/SeccionVision';
import SeccionMarcoJuridico from '../components/inicio/SeccionMarcoJuridico';
import IndiceSecciones from '../components/inicio/IndiceSecciones';
import Capitulo from '../components/inicio/Capitulo';
import { RUTAS, SECCIONES_INICIO } from '../lib/rutas';
import { useAccesoInstitucional } from '../lib/sesim/sesion';
import './Inicio.css';

// Resuelve la clave de texto `icono` de cada Eje (ver ejesEstrategicos.js,
// que no importa React) contra los componentes reales de lucide-react.
const EJE_ICONOS = { TrendingUp, Bus, Bike, ShieldAlert, Users };

const OBJETIVOS = [
  { numero: '01', tono: 'guinda', titulo: 'Organizar y territorializar', texto: 'Organizar, homologar y territorializar indicadores derivados de la legislación aplicable, la ENAMOV y estrategias estatales.' },
  { numero: '02', tono: 'marfil', titulo: 'Visualizar para decidir', texto: 'Visualizar el comportamiento de los indicadores, su estatus de cumplimiento y sus patrones territoriales para la toma de decisiones.' },
  { numero: '03', tono: 'verde', titulo: 'Preservar la trazabilidad', texto: 'Preservar la trazabilidad de origen, asociando cada indicador con su instrumento normativo, metas y medios de verificación.' },
];

const NIVELES_MIR = ['Fin', 'Propósito', 'Componentes', 'Actividades'];

const SECCIONES = [
  { id: 'introduccion', titulo: 'Introducción' },
  { id: SECCIONES_INICIO.vision, titulo: 'Visión' },
  { id: SECCIONES_INICIO.marco, titulo: 'Marco jurídico' },
  { id: 'estrategias', titulo: 'Estrategias EEMSV' },
  { id: 'clasificacion', titulo: 'Indicadores' },
  { id: 'modulos', titulo: 'Módulos' },
];

/*
 * Página de inicio con animaciones al desplazarse:
 *  · barra de progreso de lectura y desvanecimiento del título (parallax);
 *  · cada bloque con `data-revelar` aparece al entrar en pantalla (useRevelar);
 *  · cifras del catálogo que cuentan hasta su valor real (indicador, capa,
 *    instrumento_origen, unidad_territorial);
 *  · número de capas publicadas por Estrategia y distribución de los
 *    indicadores por nivel MIR, leídos del catálogo (no escritos a mano).
 */
const Inicio = () => {
  const acceso = useAccesoInstitucional();
  const pagina = useRef(null);
  const hero = useRef(null);
  const barra = useRef(null);
  const { hash } = useLocation();
  const { datos } = useCatalogo(['indicador', 'capa', 'instrumento_origen', 'unidad_territorial']);

  const cifras = useMemo(() => {
    if (!datos) return null;
    const publicas = datos.capa.filter((c) => c.estatus === 'vigente_publico');
    const capasPorEje = {};
    for (const c of publicas) {
      for (const g of c.grupos_lista ?? []) {
        const m = /Eje\s*(\d)/.exec(g.grupo || '');
        if (m) capasPorEje[m[1]] = (capasPorEje[m[1]] ?? 0) + 1;
      }
    }
    const porMir = Object.fromEntries(NIVELES_MIR.map((n) => [n, datos.indicador.filter((i) => String(i.nivel_mir).startsWith(n)).length]));
    return {
      indicadores: datos.indicador.length,
      capas: publicas.length,
      instrumentos: datos.instrumento_origen.length,
      municipios: datos.unidad_territorial.filter((u) => u.nivel === 'municipio').length,
      capasPorEje,
      porMir,
      maxMir: Math.max(...Object.values(porMir), 1),
    };
  }, [datos]);

  // Revelado al desplazarse (se vuelve a enlazar cuando llegan las cifras).
  useRevelar(pagina, [cifras]);

  // La página se lee como una historia por capítulos (Capitulo.jsx): ajuste suave al inicio de cada uno.
  useEffect(() => {
    document.documentElement.classList.add('inicio-historia');
    return () => document.documentElement.classList.remove('inicio-historia');
  }, []);

  // Barra de progreso + parallax del título, en un solo requestAnimationFrame.
  useEffect(() => {
    if (prefiereMenosMovimiento()) return undefined;
    let raf = null;
    const actualizar = () => {
      raf = null;
      const y = window.scrollY;
      const total = document.documentElement.scrollHeight - window.innerHeight;
      if (barra.current) barra.current.style.transform = `scaleX(${total > 0 ? Math.min(1, y / total) : 0})`;
      if (hero.current) {
        const p = Math.min(1, y / 700);
        hero.current.style.setProperty('--hero-y', `${y * 0.35}px`);
        hero.current.style.setProperty('--hero-o', String(1 - p * 0.9));
      }
    };
    const alDesplazar = () => {
      if (raf === null) raf = requestAnimationFrame(actualizar);
    };
    window.addEventListener('scroll', alDesplazar, { passive: true });
    actualizar();
    return () => {
      window.removeEventListener('scroll', alDesplazar);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  // Enlaces con ancla (/#marco-juridico): se lleva a la sección y se corrige mientras las
  // secciones de arriba terminan de cargar sus datos, salvo que la persona ya se haya desplazado.
  useEffect(() => {
    if (!hash) return undefined;
    let tocado = false;
    const marcar = () => { tocado = true; };
    const ir = () => {
      const nodo = document.getElementById(hash.slice(1));
      if (!tocado) (nodo?.closest('.capitulo') ?? nodo)?.scrollIntoView({ block: 'start' });
    };
    const tiempos = [120, 700, 1500, 2600].map((ms) => setTimeout(ir, ms));
    window.addEventListener('wheel', marcar, { passive: true });
    window.addEventListener('touchmove', marcar, { passive: true });
    window.addEventListener('keydown', marcar);
    return () => {
      tiempos.forEach(clearTimeout);
      window.removeEventListener('wheel', marcar);
      window.removeEventListener('touchmove', marcar);
      window.removeEventListener('keydown', marcar);
    };
  }, [hash]);

  const retardo = (i, paso = 110) => ({ '--retardo': `${i * paso}ms` });

  return (
    <div className="inicio-page" ref={pagina}>
      <div className="progreso-lectura" ref={barra} aria-hidden="true" />

      <IndiceSecciones secciones={SECCIONES} etiqueta="Secciones de Inicio" />

      <section className="portada" id="introduccion" ref={hero} aria-labelledby="portada-titulo">
        <div className="portada__claro">
          <div className="portada__marco portada__arriba">
            <div className="portada__texto">
              <h1 id="portada-titulo" className="hero-titulo-animado" aria-label="Sistema Estatal de Seguimiento a Indicadores de Movilidad y Seguridad Vial">
                <span className="portada__linea" aria-hidden="true">
                  Sistema Estatal <span className="portada__pastilla">SESIM del Estado de Campeche</span>
                </span>
                <span className="portada__linea" aria-hidden="true">de Seguimiento a Indicadores</span>
                <span className="portada__linea" aria-hidden="true">de Movilidad y Seguridad Vial</span>
              </h1>
              <p className="portada__sr">SESIM del Estado de Campeche</p>
              <div className="portada__intro" data-revelar style={retardo(1)}>
                <p>
                  El SESIM es un mecanismo que vincula información normativa, estratégica y estadística para operar en tres niveles: estatal, municipal y por instrumento de planeación.
                </p>
                <p>
                  Contribuye a consolidar un modelo de gestión pública eficiente, orientado al cumplimiento de los objetivos en materia de movilidad y seguridad vial, así como de los Planes Integrales de Movilidad Urbana Sustentable (PIMUS) municipales.
                </p>
              </div>
            </div>

            <div className="portada__mapa" aria-hidden="true">
              <StreetLinesBackground factorZoom={1.12} colorBase={[122, 84, 98]} colorPulso={[159, 34, 65]} alphaBase={0.34} grosor={1.25} />
            </div>

            <div className="portada__kpis" aria-label="Cifras del sistema">
              {[
                [Gauge, 'Indicadores', cifras?.indicadores],
                [Layers, 'Capas publicadas', cifras?.capas],
                [FileSpreadsheet, 'Instrumentos de planeación', cifras?.instrumentos],
                [MapPin, 'Municipios', cifras?.municipios],
              ].map(([Icono, etiqueta, valor], i) => (
                <div key={etiqueta} className="kpi" data-revelar style={retardo(i + 2, 120)}>
                  <Icono size={18} className="kpi__icono" aria-hidden="true" />
                  <Contador valor={valor ?? null} className="kpi__numero" />
                  <span className="kpi__etiqueta">{etiqueta}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="portada__banda">
          <div className="portada__marco">
            <h2 className="portada__banda-titulo">Objetivos</h2>
            <div className="objetivos">
              {OBJETIVOS.map((o, i) => (
                <article key={o.numero} className="objetivo" data-revelar style={retardo(i + 1, 140)} tabIndex={0}>
                  <div className="objetivo__cab">
                    <span className="objetivo__numero">{o.numero}</span>
                    <h3 className="objetivo__titulo">{o.titulo}</h3>
                  </div>
                  <p className="objetivo__texto">{o.texto}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <Capitulo titulo="Visión" tono="tinta" pantalla>
<SeccionVision id={SECCIONES_INICIO.vision} />

      </Capitulo>

      <Capitulo titulo="Marco jurídico" tono="claro">
<SeccionMarcoJuridico id={SECCIONES_INICIO.marco} />

      </Capitulo>

      <Capitulo titulo="Estrategias EEMSV" tono="tinta">
<div className="ejes-ee-section" id="estrategias">
        <h2 data-revelar>Estrategias EEMSV</h2>
        <p className="ejes-ee-subtitle" data-revelar style={retardo(1)}>
          Evaluación transversal del desempeño institucional en materia de movilidad.
        </p>
        <div className="ejes-ee-grid">
          {EJES_ESTRATEGICOS.map((eje, i) => {
            const Icono = EJE_ICONOS[eje.icono];
            const n = cifras?.capasPorEje?.[eje.numero];
            return (
              <Link
                key={eje.id}
                to={`/geovisor?estrategia=${eje.id}`}
                className="eje-ee-card"
                data-revelar
                style={{ ...retardo(i, 120), '--eje-color': eje.color }}
                title={`Ver ${eje.label} en el Geovisualizador`}
              >
                <span className="eje-ee-acento" aria-hidden="true" />
                <Icono size={28} className="eje-ee-icon" />
                <h4>{eje.tituloCorto}</h4>
                <p>{eje.descripcionCorta}</p>
                {n !== undefined && <span className="eje-ee-capas"><Contador valor={n} duracion={900} /> capas en el mapa</span>}
              </Link>
            );
          })}
        </div>
      </div>

      </Capitulo>

      <Capitulo titulo="Indicadores" tono="claro">
<div className="methodology-section" id="clasificacion">
        <h2 data-revelar>Clasificación de Indicadores</h2>
        <div className="methodology-intro" data-revelar style={retardo(1)}>
          <p>
            El modelo conceptual estructura el catálogo maestro en dos vertientes principales de evaluación institucional.
          </p>
        </div>

        <div className="methodology-sub">
          <div className="methodology-cards">
            <div className="methodology-card" data-revelar="izquierda">
              <h4>Sectoriales</h4>
              <p>
                Monitorean y evalúan los resultados de las dependencias que integran el Sistema Estatal de Movilidad y Seguridad Vial. Sectores de medición:
              </p>
              <ul className="methodology-lista">
                {['Gobierno y Administración.', 'Ambiente, Cambio Climático y Gestión Integral de Riesgos.', 'Observatorios Ciudadanos.', 'Inclusión y Género.'].map((t, i) => (
                  <li key={t} data-revelar style={retardo(i + 2, 90)}>{t}</li>
                ))}
              </ul>
            </div>

            <div className="methodology-card" data-revelar="derecha">
              <h4>Desempeño</h4>
              <p>
                Permiten medir los logros obtenidos conforme a los objetivos planteados al final de la ejecución de la EEMSV. Horizontes de planeación:
              </p>
              <ul className="methodology-lista">
                {['Inmediato y Corto plazo.', 'Mediano plazo.', 'Largo plazo.'].map((t, i) => (
                  <li key={t} data-revelar style={retardo(i + 2, 90)}>{t}</li>
                ))}
              </ul>
            </div>
          </div>

          {cifras && (
            <div className="mir-bloque" data-revelar>
              <h3>Catálogo por nivel de la Matriz de Indicadores para Resultados</h3>
              <p className="methodology-sub-desc">{cifras.indicadores} indicadores del catálogo, según su nivel MIR.</p>
              <div className="mir-barras">
                {NIVELES_MIR.map((nivel, i) => (
                  <div key={nivel} className="mir-fila" style={retardo(i, 150)}>
                    <span className="mir-etiqueta">{nivel}</span>
                    <span className="mir-pista">
                      <span className="mir-relleno" style={{ '--ancho': `${(100 * cifras.porMir[nivel]) / cifras.maxMir}%`, ...retardo(i, 150) }} />
                    </span>
                    <Contador valor={cifras.porMir[nivel]} duracion={1100} className="mir-valor" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      </Capitulo>

      <Capitulo titulo="Módulos" tono="tinta">
      <div className="modules-section" id="modulos">
        <h2 data-revelar>Módulos del Sistema</h2>
        <div className="module-cards">
          {[
            { icono: MapPin, titulo: 'Geovisor', texto: 'Explore las capas territoriales de diagnóstico y estrategias en el mapa interactivo.', a: RUTAS.geovisor, cta: 'Abrir el Geovisor' },
            { icono: BookOpen, titulo: 'Catálogo de instrumentos', texto: 'Consulte leyes, programas y normas técnicas con su ficha y documento oficial.', a: RUTAS.catalogo, cta: 'Ver el catálogo' },
            { icono: FileSpreadsheet, titulo: 'Seguimiento de proyectos e indicadores', texto: 'Tablero de KPI, fichas de indicadores, cartera de proyectos y reportes para usuarios institucionales.', a: RUTAS.seguimiento, cta: acceso ? 'Ir al seguimiento' : 'Acceso institucional', institucional: true },
          ].map(({ icono: Icono, titulo, texto, a, cta, institucional }, i) => (
            <div key={a} className="module-card" data-revelar style={retardo(i, 150)}>
              <Icono size={32} className="card-icon" />
              <h3>{titulo}</h3>
              <p>{texto}</p>
              {institucional ? (
                <EnlaceInstitucional to={a} sinAcceso="acceso" className="card-link">
                  {cta} <ArrowRight size={16} aria-hidden="true" />
                </EnlaceInstitucional>
              ) : (
                <Link to={a} className="card-link">
                  {cta} <ArrowRight size={16} aria-hidden="true" />
                </Link>
              )}
            </div>
          ))}
        </div>
      </div>
      </Capitulo>
    </div>
  );
};

export default Inicio;
