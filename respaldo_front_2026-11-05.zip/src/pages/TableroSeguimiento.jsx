import { useRef } from 'react';
import { useRevelar } from '../lib/useRevelar';
import ImpactoEsperado from '../components/inicio/ImpactoEsperado';
import '../components/inicio/SeccionInicio.css';

/**
 * Tablero de seguimiento (público). Por ahora conserva, tal como estaba en Inicio, el bloque
 * «Impacto esperado»: cobertura del sistema por municipio con su filtro, cifras e instrumentos locales.
 */
export default function TableroSeguimiento() {
  const pagina = useRef(null);
  useRevelar(pagina, []);
  return (
    <div className="inicio-page tablero-publico" ref={pagina}>
      <section className="seccion-inicio" aria-labelledby="tablero-publico-titulo">
        <header className="seccion-inicio__cabecera" data-revelar>
          <span className="seccion-inicio__antetitulo">Tablero de seguimiento</span>
          <h2 id="tablero-publico-titulo">Cobertura del sistema por municipio</h2>
        </header>
        <ImpactoEsperado />
      </section>
    </div>
  );
}
