import { useEffect, useId, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDown, ArrowUp, BarChart3, Bike, BookOpen, Bus, BusFront, Car, Database, ExternalLink, FileText, FolderKanban, Landmark, Link2, Map as MapIcon, MapPin, PersonStanding, Scale, ScrollText, Settings, Target, Truck } from 'lucide-react';
import { useCatalogo, useContenido } from '../../lib/sesim/useCatalogo';
import { RUTAS, enlace } from '../../lib/rutas';
import { publicables, relacionesVerificadas, fmtPublicacion } from '../../lib/sesim/normativo';
import PiramideNormativa from '../marco/PiramideNormativa';
import EstadoCarga, { Esqueleto } from '../plataforma/EstadoCarga';
import EnlaceInstitucional from '../plataforma/EnlaceInstitucional';
import { RELACIONES } from '../../lib/sesim/trazabilidad';
import { fmtNumero } from '../tablero/formato';
import './SeccionMarcoJuridico.css';

const TABLAS = ['instrumento_normativo', 'relacion_normativa', 'indicador', 'indicador_instrumento', 'instrumento_origen', 'matriz_instrumento', 'capa'];
const CADENA = [
  { icono: Landmark, titulo: 'Instrumento', texto: 'Ley, estrategia o programa que origina la obligación', a: RUTAS.catalogo },
  { icono: Target, titulo: 'Estrategia y meta', texto: 'Objetivo y línea de acción documentados', a: RUTAS.indicadores, institucional: true },
  { icono: BarChart3, titulo: 'Indicador', texto: 'Fórmula, línea base, meta y semáforo', a: RUTAS.tablero, institucional: true },
  { icono: FolderKanban, titulo: 'Proyecto', texto: 'Responsable, avance y cumplimiento', a: RUTAS.proyectos, institucional: true },
  { icono: Database, titulo: 'Fuente y evidencia', texto: 'Registro oficial, fecha y validación', a: `${RUTAS.proyectos}?pestana=datos`, institucional: true },
  { icono: MapPin, titulo: 'Territorio', texto: 'Resultado observable en el mapa', a: RUTAS.geovisor },
];

const esUrl = (v) => typeof v === 'string' && /^https?:\/\//i.test(v);

function TarjetaInstrumento({ doc, indice, resaltado, onIr }) {
  const ref = useRef(null);
  useEffect(() => {
    if (resaltado) ref.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [resaltado]);
  const traza = doc.id_instrumento_origen ? indice.trazaPorInstrumento.get(doc.id_instrumento_origen) : null;
  const metas = doc.id_instrumento_origen ? indice.metasPorInstrumento.get(doc.id_instrumento_origen) ?? 0 : 0;
  const pdfSesim = doc.id_instrumento_origen ? indice.origen.get(doc.id_instrumento_origen)?.ruta_pdf : null;
  const relaciones = indice.relaciones.filter((r) => r.instrumento_origen === doc.id || r.instrumento_destino === doc.id);

  return (
    <article ref={ref} className={`traza-doc${resaltado ? ' traza-doc--resaltado' : ''}`} aria-labelledby={`doc-${doc.id}`}>
      <div className="traza-doc__cabecera">
        <code>{doc.clave}</code>
        {doc.tipo && <span className="traza-tipo">{doc.tipo}</span>}
      </div>
      <h4 id={`doc-${doc.id}`}>{doc.nombre_oficial ?? doc.nombre}</h4>
      {doc.descripcion && <p className="traza-doc__texto">{doc.descripcion}</p>}
      {(doc.publicacion || doc.ultima_reforma) && (
        <dl className="traza-doc__fechas">
          {doc.publicacion && <><dt>Publicación</dt><dd>{fmtPublicacion(doc.publicacion)}</dd></>}
          {doc.ultima_reforma && <><dt>Última reforma</dt><dd>{fmtPublicacion(doc.ultima_reforma)}</dd></>}
        </dl>
      )}
      {doc.articulos_verificados?.length > 0 && (
        <ul className="traza-doc__articulos">
          {doc.articulos_verificados.map((a) => <li key={a.articulo}><strong>Art. {a.articulo}.</strong> {a.materia}</li>)}
        </ul>
      )}

      {relaciones.length > 0 && (
        <div className="traza-doc__relaciones">
          <span>Relación con:</span>
          {relaciones.map((r) => {
            const otro = r.instrumento_origen === doc.id ? r.instrumento_destino : r.instrumento_origen;
            const d = indice.porId.get(otro);
            return d ? (
              <button key={r.id} type="button" onClick={() => onIr(d)} title={`Ir a ${d.nombre}`}>
                {siglas(d.nombre)}
              </button>
            ) : null;
          })}
        </div>
      )}

      <div className="traza-doc__enlaces">
        {doc.url_oficial ? (
          <a href={doc.url_oficial} target="_blank" rel="noopener noreferrer" className="traza-enlace traza-enlace--primario">
            <ExternalLink size={14} aria-hidden="true" /> Documento oficial<span className="sr-only"> de {doc.nombre} (se abre en una pestaña nueva)</span>
          </a>
        ) : doc.enlaces[0] ? (
          <a href={doc.enlaces[0].url} target="_blank" rel="noopener noreferrer" className="traza-enlace">
            <ExternalLink size={14} aria-hidden="true" /> {doc.enlaces[0].titulo}<span className="sr-only"> (se abre en una pestaña nueva)</span>
          </a>
        ) : null}
        {esUrl(pdfSesim) && (
          <a href={pdfSesim} target="_blank" rel="noopener noreferrer" className="traza-enlace">
            <FileText size={14} aria-hidden="true" /> PDF en el SESIM<span className="sr-only"> (se abre en una pestaña nueva)</span>
          </a>
        )}
        <Link to={enlace.fichaInstrumento(doc.id)} className="traza-enlace">
          <FileText size={14} aria-hidden="true" /> Ficha técnica
        </Link>
      </div>

      {(traza || metas > 0) && (
        <div className="traza-doc__indicadores">
          <span><BarChart3 size={14} aria-hidden="true" /> Indicadores del SESIM vinculados</span>
          <ul>
            {RELACIONES.filter((rel) => traza?.[rel.clave]).map((rel) => (
              <li key={rel.clave} title={rel.ayuda}>
                <EnlaceInstitucional to={enlace.indicadoresDeInstrumento(doc.id_instrumento_origen, rel.clave)} className="traza-enlace traza-enlace--indicadores">
                  <strong>{fmtNumero(traza[rel.clave])}</strong> {rel.clave === 'origen' ? 'de origen' : `con ${rel.etiqueta.toLowerCase()}`}
                </EnlaceInstitucional>
              </li>
            ))}
          </ul>
          {metas > 0 && <small>{fmtNumero(metas)} metas registradas en la matriz del instrumento</small>}
        </div>
      )}
    </article>
  );
}

const siglas = (nombre) => /\(([^)]+)\)\s*$/.exec(nombre)?.[1] ?? nombre;

/** Cita en línea: «LGMSV, art. 6» enlazada al texto oficial del ordenamiento. */
function Cita({ cita, ordenamientos }) {
  const o = ordenamientos[cita.ordenamiento];
  if (!o) return null;
  return (
    <a className="cita" href={o.url} target="_blank" rel="noopener noreferrer" title={`${o.nombre}. ${o.publicacion ?? ''}`.trim()}>
      {o.sigla}, {cita.articulo}
      <ExternalLink size={11} aria-hidden="true" />
      <span className="sr-only"> ({o.nombre}; se abre en una pestaña nueva)</span>
    </a>
  );
}

function Citas({ citas = [], ordenamientos }) {
  if (!citas.length) return null;
  return (
    <span className="citas">
      ({citas.map((c, k) => (
        <span key={`${c.ordenamiento}-${c.articulo}`}>{k > 0 && '; '}<Cita cita={c} ordenamientos={ordenamientos} /></span>
      ))})
    </span>
  );
}

/** «¿A quién se alinea?» / «¿A quién orienta?»: solo el instrumento; su enunciado y fundamento aparecen al pasar el cursor o al enfocarlo. */
function BloqueVinculos({ pregunta, etiqueta, icono: Icono, items = [], ordenamientos }) {
  const base = useId();
  if (!items.length) return null;
  return (
    <section className="vinculos">
      <h4>{pregunta}</h4>
      <p className="vinculos__etiqueta"><Icono size={16} aria-hidden="true" /> {etiqueta}</p>
      <ul>
        {items.map((it, k) => (
          <li key={`${it.ordenamiento}-${it.articulo}-${it.texto.slice(0, 24)}`} className="vinculos__item">
            <button type="button" className="vinculos__nombre" aria-describedby={`${base}-${k}`}>{it.con ?? siglas(ordenamientos[it.ordenamiento]?.nombre ?? '')}</button>
            <p id={`${base}-${k}`} className="vinculos__detalle">
              {it.texto} <Citas citas={[it]} ordenamientos={ordenamientos} />
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

const ICONOS_JERARQUIA = { peaton: PersonStanding, ciclista: Bike, autobus: Bus, prestador: BusFront, carga: Truck, particular: Car };

/** Bloque que se despliega al pasar el cursor; con teclado o en pantallas táctiles se abre con su encabezado. */
function Plegable({ titulo, resumen, abiertoInicial = false, children }) {
  const [abierto, setAbierto] = useState(abiertoInicial);
  return (
    <details className="plegable" open={abierto} onMouseEnter={() => setAbierto(true)} onMouseLeave={() => setAbierto(false)} onToggle={(e) => setAbierto(e.currentTarget.open)}>
      <summary className="plegable__resumen">
        <span className="marco-panel__titulo marco-panel__titulo--sub">{titulo}</span>
        <small>{resumen}</small>
      </summary>
      <div className="plegable__cuerpo">{children}</div>
    </details>
  );
}

/** Sección «Marco jurídico» de Inicio: pirámide de instrumentos con su descripción, vínculos y fundamento. */
export default function SeccionMarcoJuridico({ id }) {
  const { datos, error } = useCatalogo(TABLAS);
  const piramide = useContenido('piramide_normativa');
  const [nivel, setNivel] = useState(null);
  const [resaltado, setResaltado] = useState(null);

  const contenido = piramide.datos;
  const indice = useMemo(() => {
    if (!datos || !contenido) return null;
    const publicados = publicables(datos.instrumento_normativo);
    const excluidos = new Set(contenido.tipos_excluidos ?? []);
    const normativo = publicados.filter((d) => !excluidos.has(d.tipo));
    const porNivel = new Map();
    for (const d of normativo) {
      if (!porNivel.has(d.nivel_piramide)) porNivel.set(d.nivel_piramide, []);
      porNivel.get(d.nivel_piramide).push(d);
    }
    const activos = new Set(datos.indicador.filter((i) => i.activo !== false).map((i) => i.id));
    const trazaPorInstrumento = new Map();
    for (const v of datos.indicador_instrumento) {
      if (!activos.has(v.id_indicador)) continue;
      if (!trazaPorInstrumento.has(v.id_instrumento)) trazaPorInstrumento.set(v.id_instrumento, {});
      const t = trazaPorInstrumento.get(v.id_instrumento);
      (t[v.correspondencia] ??= new Set()).add(v.id_indicador);
    }
    const metasPorInstrumento = new Map();
    for (const m of datos.matriz_instrumento) metasPorInstrumento.set(m.id_instrumento, (metasPorInstrumento.get(m.id_instrumento) ?? 0) + 1);
    return {
      porNivel,
      conteos: new Map([...porNivel].map(([k, v]) => [k, v.length])),
      porId: new Map(normativo.map((d) => [d.id, d])),
      origen: new Map(datos.instrumento_origen.map((o) => [o.id, o])),
      relaciones: relacionesVerificadas(datos.relacion_normativa),
      trazaPorInstrumento: new Map([...trazaPorInstrumento].map(([k, t]) => [k, Object.fromEntries(Object.entries(t).map(([c, ids]) => [c, ids.size]))])),
      metasPorInstrumento,
      noms: normativo.filter((d) => d.tipo === 'Norma Oficial Mexicana'),
      enCatalogo: publicados.length,
      indicadores: activos.size,
      capas: datos.capa.filter((c) => c.estatus === 'vigente_publico').length,
    };
  }, [datos, contenido]);

  const niveles = useMemo(() => contenido?.niveles ?? [], [contenido]);
  const ordenamientos = contenido?.ordenamientos ?? {};
  const escalas = contenido?.escalas ?? {};
  const seleccionado = nivel ?? niveles.at(-1)?.nivel ?? null;
  const actual = niveles.find((n) => n.nivel === seleccionado);
  const superior = niveles.find((n) => n.nivel === seleccionado + 1);
  const inferior = niveles.find((n) => n.nivel === seleccionado - 1);
  const docs = indice?.porNivel.get(seleccionado) ?? [];
  const fallo = error || piramide.error;

  const elegirNivel = (n) => {
    setNivel(n);
    setResaltado(null);
  };
  const irA = (doc) => {
    setNivel(doc.nivel_piramide);
    setResaltado(doc.id);
  };

  return (
    <section id={id} className="seccion-inicio marco-inicio" aria-labelledby={`${id}-titulo`}>
      <header className="seccion-inicio__cabecera marco-inicio__cabecera" data-revelar>
        <span className="seccion-inicio__antetitulo">Marco jurídico y programático</span>
        <h2 id={`${id}-titulo`}>Pirámide de instrumentos de planeación</h2>
        {contenido?.lema && (
          <>
            <p className="marco-inicio__lema">{contenido.lema.texto}</p>
            <section className="marco-inicio__escala marco-inicio__escala--cabecera" aria-label="Escala de cada peldaño">
              <h4>Escala</h4>
              <ul className="marco-inicio__escalas">
                {Object.entries(escalas).map(([k, v]) => (
                  <li key={k}><span className={`piramide-badge piramide-badge--${k}`} aria-hidden="true">{k}</span> {v}</li>
                ))}
              </ul>
            </section>
          </>
        )}
      </header>

      {fallo && <EstadoCarga estado="error" titulo="No se pudo cargar el marco normativo" mensaje={fallo} accion={{ etiqueta: 'Reintentar', onClick: () => window.location.reload() }} />}
      {!fallo && (!indice || !actual) && <Esqueleto alto={560} etiqueta="Cargando la pirámide de instrumentos" />}

      {indice && actual && (
        <div className="marco-inicio__cuerpo" data-revelar>
          <div className="marco-panel marco-inicio__descripcion" aria-live="polite" aria-labelledby="marco-desc-titulo">
            <h3 className="marco-panel__titulo"><BookOpen size={22} aria-hidden="true" /> Descripción</h3>
            <div key={actual.nivel} className="marco-panel__cambio">
              <span className="marco-inicio__nivel">Escala {escalas[actual.escala]?.toLowerCase()}</span>
              <h4 id="marco-desc-titulo" className="marco-inicio__nombre">{actual.titulo}</h4>
              <p className="marco-inicio__objetivo">
                {actual.descripcion.texto} <Citas citas={actual.descripcion.citas} ordenamientos={ordenamientos} />
              </p>

              <Plegable titulo={<><Link2 size={18} aria-hidden="true" /> Vínculos</>} resumen={actual.nivel === niveles.length ? 'Módulos del SESIM' : `${docs.length} instrumentos de este peldaño`} abiertoInicial={!!resaltado || actual.nivel === niveles.length}>
                {actual.nivel === niveles.length ? (
                  <div className="marco-inicio__modulos">
                    {[
                      { a: RUTAS.inicio, icono: Landmark, titulo: 'Portal SESIM', texto: 'Inicio del sistema' },
                      { a: RUTAS.geovisor, icono: MapIcon, titulo: 'Geovisor de movilidad', texto: `${fmtNumero(indice.capas)} capas publicadas` },
                      { a: RUTAS.catalogo, icono: FileText, titulo: 'Catálogo de instrumentos', texto: `${fmtNumero(indice.enCatalogo)} instrumentos con documento oficial` },
                      { a: RUTAS.tablero, icono: BarChart3, titulo: 'Tablero de indicadores', texto: `${fmtNumero(indice.indicadores)} indicadores en seguimiento`, institucional: true },
                      { a: RUTAS.proyectos, icono: FolderKanban, titulo: 'Proyectos y reportes', texto: 'Metas, avance y series históricas', institucional: true },
                    ].map(({ a, icono: Icono, titulo, texto, institucional }) => {
                      const cuerpo = <><Icono size={18} aria-hidden="true" /><strong>{titulo}</strong><span>{texto}</span></>;
                      return institucional
                        ? <EnlaceInstitucional key={a} to={a} sinAcceso="acceso" className="marco-inicio__modulo">{cuerpo}</EnlaceInstitucional>
                        : <Link key={a} to={a} className="marco-inicio__modulo">{cuerpo}</Link>;
                    })}
                  </div>
                ) : docs.length ? (
                  <div className="marco-inicio__docs">
                    {docs.map((d) => <TarjetaInstrumento key={d.id} doc={d} indice={indice} resaltado={resaltado === d.id} onIr={irA} />)}
                  </div>
                ) : (
                  <EstadoCarga estado="vacio" mensaje="El banco documental no registra instrumentos publicados en este peldaño." compacto />
                )}
              </Plegable>
            </div>
          </div>

          <div className="marco-inicio__piramide">
            <PiramideNormativa niveles={niveles} conteos={indice.conteos} escalas={escalas} seleccionado={seleccionado} onSeleccionar={elegirNivel} />
            {contenido?.lema && <p className="marco-inicio__lema-fuente marco-inicio__lema-fuente--pie">Fuente: <Citas citas={contenido.lema.citas} ordenamientos={ordenamientos} /></p>}
          </div>

          <aside className="marco-panel marco-inicio__concordancia" aria-live="polite" aria-labelledby="marco-conc-titulo">
            <h3 id="marco-conc-titulo" className="marco-panel__titulo"><Scale size={22} aria-hidden="true" /> Alineación normativa</h3>
            <div key={actual.nivel} className="marco-panel__cambio">
              <BloqueVinculos pregunta="¿A quién se alinea?" etiqueta="Concordancia con:" icono={ArrowUp} items={actual.concordancia} ordenamientos={ordenamientos} />
              <BloqueVinculos pregunta="¿A quién orienta?" etiqueta="Orienta a:" icono={ArrowDown} items={actual.orientacion} ordenamientos={ordenamientos} />
            </div>
            <nav className="marco-inicio__pasos" aria-label="Peldaños contiguos">
              {(actual.fundamenta_en ?? (inferior ? [{ nivel: inferior.nivel, texto: inferior.titulo }] : [])).map((f) => (
                <button key={`${f.nivel}-${f.texto}`} type="button" onClick={() => elegirNivel(f.nivel)}>
                  <ArrowUp size={15} aria-hidden="true" /> <span><small>Se fundamenta en</small>{f.texto}</span>
                </button>
              ))}
              {superior && (
                <button type="button" onClick={() => elegirNivel(superior.nivel)}>
                  <ArrowDown size={15} aria-hidden="true" /> <span><small>Orienta a</small>{superior.titulo}</span>
                </button>
              )}
            </nav>
          </aside>
        </div>
      )}

      {contenido?.jerarquia && (
        <div className="eje-movilidad" data-revelar>
          <h3 className="eje-movilidad__titulo"><span>{contenido.jerarquia.titulo}</span></h3>
          <ol className="eje-movilidad__grupos">
            {contenido.jerarquia.grupos.map((g) => {
              const Icono = ICONOS_JERARQUIA[g.icono] ?? PersonStanding;
              return (
                <li key={`${g.fraccion}-${g.etiqueta}`} title={g.detalle}>
                  <Icono size={30} strokeWidth={1.8} aria-hidden="true" />
                  <strong>{g.etiqueta}</strong>
                  <small>Fracción {g.fraccion}<span className="sr-only">: {g.detalle}</span></small>
                </li>
              );
            })}
          </ol>
          <p className="eje-movilidad__nota">{contenido.jerarquia.texto} <Citas citas={contenido.jerarquia.citas} ordenamientos={ordenamientos} /></p>
        </div>
      )}

      {indice?.noms.length > 0 && (
        <div className="marco-inicio__tecnico" data-revelar>
          <Settings size={30} aria-hidden="true" className="marco-inicio__tecnico-icono" />
          <div>
            <h3>Marco técnico transversal</h3>
            <ul>
              {indice.noms.map((d) => (
                <li key={d.id}>
                  {d.url_oficial ? (
                    <a href={d.url_oficial} target="_blank" rel="noopener noreferrer" title={`${d.nombre_oficial ?? d.nombre}. ${fmtPublicacion(d.publicacion) ?? ''}`}>
                      {d.nombre}<ExternalLink size={11} aria-hidden="true" /><span className="sr-only"> (DOF; se abre en una pestaña nueva)</span>
                    </a>
                  ) : d.nombre}
                </li>
              ))}
            </ul>
          </div>
          <Link to={RUTAS.catalogo} className="marco-inicio__tecnico-catalogo" aria-label="Ver las normas en el catálogo de instrumentos"><ScrollText size={30} aria-hidden="true" /></Link>
        </div>
      )}

      {contenido && (
        <footer className="marco-inicio__fuentes" data-revelar>
          <h3>Fuentes oficiales</h3>
          <ul>
            {contenido.portales.map((p) => (
              <li key={p.url}>
                <a href={p.url} target="_blank" rel="noopener noreferrer">{p.nombre}<ExternalLink size={11} aria-hidden="true" /><span className="sr-only"> (se abre en una pestaña nueva)</span></a>
              </li>
            ))}
          </ul>
          <p>{contenido.fuente}</p>
        </footer>
      )}

      <div className="cadena" data-revelar>
        <h3>¿Cómo se sigue la traza?</h3>
        <ol className="cadena__pasos">
          {CADENA.map(({ icono: Icono, titulo, texto, a, institucional }, k) => {
            const cuerpo = (
              <>
                <span className="cadena__num" aria-hidden="true">{k + 1}</span>
                <Icono size={20} aria-hidden="true" />
                <strong>{titulo}</strong>
                <span>{texto}</span>
              </>
            );
            return (
              <li key={titulo}>
                {institucional
                  ? <EnlaceInstitucional to={a} className="cadena__paso">{cuerpo}</EnlaceInstitucional>
                  : <Link to={a} className="cadena__paso">{cuerpo}</Link>}
              </li>
            );
          })}
        </ol>
      </div>
    </section>
  );
}
