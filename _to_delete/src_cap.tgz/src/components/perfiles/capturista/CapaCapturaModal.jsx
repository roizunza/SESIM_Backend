import { useMemo, useState } from 'react';
import { X, UploadCloud, ArrowLeft, ArrowRight, CheckCircle2, AlertTriangle, XCircle, Lock, Send, Save, Map as MapaIcono } from 'lucide-react';
import { guardarCapa, enviarCapaARevision } from '../../../lib/sesim/catalogoApi';
import { ESTATUS_CAPA } from '../../../lib/sesim/capas';
import '../comun/Comun.css';
import './CapaCaptura.css';

/**
 * Subir o actualizar una capa (perfil Capturista). Todo se elige de listas; el sistema revisa el archivo
 * y lo rechaza en el acto si no cumple (proyección, geometría, identificador…).
 *
 * Reglas (acordadas con el equipo SESIM):
 *  · Un solo sistema de coordenadas: EPSG:4326 (WGS 84), el mismo de las teselas.
 *  · Formatos: GeoJSON se revisa aquí; GeoPackage y Shapefile comprimido los revisa el servicio de procesos
 *    cuando esté habilitado (hoy se avisa y no se aceptan).
 *  · El ID, el instrumento, el tipo de geometría y el número de elementos los pone el sistema.
 *  · Solo se escribe texto en: título (capa nueva), propósito, nota de linaje y, si la capa cambia 20 % o más,
 *    la justificación (la revisa el administrador).
 *  · Una capa ya validada/publicada no se edita: el administrador debe devolverla a borrador (fn_guardar_capa).
 *
 * Honestidad técnica: hoy se guarda la FICHA y el conteo de elementos; los elementos geográficos llegarán a
 * PostGIS con el servicio de ingesta (Ciclo 9).
 */
export const TOPE_MB = 100;
const GEOM = { Point: 'Punto', MultiPoint: 'Punto', LineString: 'Línea', MultiLineString: 'Línea', Polygon: 'Polígono', MultiPolygon: 'Polígono' };
const GEOM_LEAFLET = { Punto: 'point', Línea: 'line', Polígono: 'polygon' };
// Península de Yucatán con margen: fuera de esto casi seguro es otro sistema de coordenadas o un error de captura.
const CAJA = { oeste: -93.6, este: -85.5, sur: 16.4, norte: 23.2 };
const PERIODICIDADES = ['Anual', 'Bienal', 'Quinquenal', 'Decenal', 'Irregular', 'No planeada'];
const PASOS_LINAJE = ['Descarga de una fuente oficial', 'Captura o levantamiento en campo', 'Digitalización', 'Integración de varias fuentes', 'Homologación de atributos', 'Reproyección a EPSG:4326'];
const MOTIVOS = ['Ampliación (se agregan elementos)', 'Depuración (se corrigen o quitan elementos)', 'Actualización de corte'];
const UMBRAL_VARIACION = 0.2;

/** Revisión inmediata del GeoJSON. Cada fila: qué se revisó, qué se encontró y si pasa. */
export function revisarGeojson(gj, tipoEsperado = null) {
  const filas = [];
  const fila = (que, encontrado, bien, ayuda) => filas.push({ que, encontrado, bien, ayuda });
  const feats = Array.isArray(gj?.features) ? gj.features : [];
  fila('Formato', gj?.type === 'FeatureCollection' ? 'Colección de elementos' : String(gj?.type ?? 'No reconocido'), gj?.type === 'FeatureCollection', 'Exporta la capa como GeoJSON (FeatureCollection).');
  const crs = gj?.crs?.properties?.name;
  const crsOk = !crs || /4326|CRS84/i.test(crs);
  fila('Sistema de coordenadas', crs ?? 'EPSG:4326 (por omisión)', crsOk, 'Reproyecta la capa a EPSG:4326 (WGS 84) antes de subirla.');
  fila('Elementos', `${feats.length}`, feats.length > 0, 'La capa no puede estar vacía.');

  const vacios = feats.filter((f) => !f?.geometry?.coordinates || !f.geometry.coordinates.length).length;
  fila('Geometrías con contenido', vacios ? `${vacios} vacías o nulas` : 'Todas con contenido', vacios === 0, 'Elimina los registros sin geometría.');

  const familias = new Set(feats.map((f) => GEOM[f?.geometry?.type]).filter(Boolean));
  const tipo = familias.size === 1 ? [...familias][0] : null;
  fila('Tipo de geometría', [...familias].join(' + ') || '—', familias.size === 1, 'Una capa solo puede tener puntos, líneas o polígonos, no mezclados.');
  if (tipoEsperado) fila('Coincide con la capa vigente', tipo ? `${tipo} (vigente: ${tipoEsperado})` : '—', tipo === tipoEsperado, 'Para cambiar el tipo de geometría se debe dar de alta una capa nueva.');

  let noNum = 0; let fuera = 0; let anillos = 0; let total = 0;
  const punto = (c) => {
    total += 1;
    if (!Number.isFinite(c[0]) || !Number.isFinite(c[1])) { noNum += 1; return; }
    if (c[0] < CAJA.oeste || c[0] > CAJA.este || c[1] < CAJA.sur || c[1] > CAJA.norte) fuera += 1;
  };
  const recorrer = (c, tipoGeom) => {
    if (typeof c[0] === 'number') { punto(c); return; }
    if (/Polygon/.test(tipoGeom) && typeof c[0]?.[0] === 'number') {
      if (c.length < 4 || c[0][0] !== c[c.length - 1][0] || c[0][1] !== c[c.length - 1][1]) anillos += 1;
    }
    c.forEach((x) => recorrer(x, tipoGeom));
  };
  feats.forEach((f) => f?.geometry?.coordinates && recorrer(f.geometry.coordinates, f.geometry.type));
  fila('Coordenadas numéricas', noNum ? `${noNum} inválidas` : 'Correctas', noNum === 0, 'Hay coordenadas vacías o con texto.');
  fila('Ubicación (península de Yucatán)', fuera ? `${fuera} de ${total} puntos fuera` : 'Dentro del territorio', fuera === 0, 'Parece estar en otro sistema de coordenadas (metros, UTM) o fuera del estado. Reproyecta a EPSG:4326.');
  fila('Polígonos cerrados', anillos ? `${anillos} anillos abiertos` : 'Todos cerrados', anillos === 0, 'Corrige la geometría en tu SIG (Reparar geometrías).');

  const columnas = [...new Set(feats.slice(0, 1000).flatMap((f) => Object.keys(f?.properties ?? {})))];
  return { filas, columnas, n: feats.length, tipo, valido: filas.every((x) => x.bien) && feats.length > 0 };
}

/** Revisa el identificador elegido (id_origen): lleno y sin repetidos. */
function revisarIdentificador(gj, columna) {
  if (!columna) return { bien: false, texto: 'Elige la columna que identifica cada elemento.' };
  const feats = gj.features ?? [];
  const vistos = new Set(); let vacios = 0; let repetidos = 0;
  feats.forEach((f) => {
    const v = f.properties?.[columna];
    if (v === null || v === undefined || String(v).trim() === '') { vacios += 1; return; }
    const k = String(v);
    if (vistos.has(k)) repetidos += 1; else vistos.add(k);
  });
  if (vacios) return { bien: false, texto: `${vacios} elementos sin valor en «${columna}».` };
  if (repetidos) return { bien: false, texto: `${repetidos} valores repetidos en «${columna}»: cada elemento necesita uno único.` };
  return { bien: true, texto: `«${columna}» identifica a los ${feats.length} elementos sin repetirse.` };
}

const unicos = (lista) => [...new Set(lista.filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));

export default function CapaCapturaModal({ abierto, modo = 'nueva', capaInicial = null, catalogo, onClose, onGuardada, onVistaPrevia }) {
  const actualizar = modo === 'actualizar';
  const [paso, setPaso] = useState(actualizar && !capaInicial ? 0 : 1);
  const [idBase, setIdBase] = useState(capaInicial?.id ?? '');
  const [archivo, setArchivo] = useState(null);
  const [gj, setGj] = useState(null);
  const [rechazo, setRechazo] = useState('');
  const [colId, setColId] = useState('');
  const [ficha, setFicha] = useState({ nomenclatura: '', grupo: '', titulo: '', custodio: '', fuente: '', periodicidad: '', restriccion: '', corte: '', proposito: '', pasos: [], notaLinaje: '', motivo: '', justificacion: '' });
  const [doc, setDoc] = useState(null);
  const [estado, setEstado] = useState({ ocupado: false, error: '', hecho: '' });

  const capas = useMemo(() => catalogo?.capa ?? [], [catalogo]);
  const base = actualizar ? capas.find((c) => c.id === idBase) ?? null : null;

  const nomenclaturas = useMemo(() => {
    const m = new Map();
    for (const c of capas) {
      const prefijo = c.id.replace(/\d+$/, '');
      const num = Number(c.id.match(/(\d+)$/)?.[1] ?? 0);
      const prev = m.get(c.nomenclatura) ?? { prefijo, max: 0, categoria: c.categoria, grupos: new Set() };
      prev.max = Math.max(prev.max, num);
      (c.grupos_lista ?? []).forEach((g) => g.grupo && prev.grupos.add(g.grupo));
      m.set(c.nomenclatura, prev);
    }
    return m;
  }, [capas]);
  const custodios = useMemo(() => unicos(capas.map((c) => c.responsable)), [capas]);
  const fuentes = useMemo(() => unicos(capas.map((c) => c.metadatos_extra?.fuente_origen)), [capas]);

  if (!abierto) return null;

  const nom = nomenclaturas.get(ficha.nomenclatura);
  const idNuevo = nom ? `${nom.prefijo}${String(nom.max + 1).padStart(2, '0')}` : '';
  const instrumento = nom && nom.categoria !== 'mapa_base'
    ? (catalogo?.instrumento_origen ?? []).find((i) => /eemsv01/i.test(i.id)) ?? null
    : null;
  const tituloRepetido = capas.some((c) => c.titulo.trim().toLowerCase() === ficha.titulo.trim().toLowerCase());
  const revision = gj ? revisarGeojson(gj, actualizar ? base?.tipo_geometria : null) : null;
  const ident = gj && revision?.valido ? revisarIdentificador(gj, colId) : null;
  const previo = actualizar ? Number(base?.n_elementos ?? 0) : 0;
  const variacion = actualizar && previo > 0 && revision ? Math.abs(revision.n - previo) / previo : 0;
  const pideJustificacion = variacion >= UMBRAL_VARIACION;
  const fijar = (k) => (e) => setFicha((f) => ({ ...f, [k]: e.target.value }));

  const cerrar = () => { onClose(); };

  const leer = async (f) => {
    setRechazo(''); setGj(null); setArchivo(null); setColId('');
    if (!f) return;
    const ext = (f.name.split('.').pop() || '').toLowerCase();
    if (['kml', 'kmz', 'dwg', 'dxf', 'gdb', 'lyr', 'tif', 'tiff', 'csv', 'xlsx', 'xls'].includes(ext)) {
      setRechazo(`Rechazado: el formato .${ext} no se acepta. Usa GeoPackage (recomendado), Shapefile comprimido (.zip) o GeoJSON.`);
      return;
    }
    if (['gpkg', 'zip', 'shp'].includes(ext)) {
      setRechazo('Este formato lo revisa el servicio de procesos, que aún no está habilitado. Por ahora exporta la capa como GeoJSON en EPSG:4326 (en QGIS: clic derecho › Exportar › Guardar objetos como…).');
      return;
    }
    if (!['geojson', 'json'].includes(ext)) { setRechazo(`Rechazado: la extensión .${ext || '(ninguna)'} no es una de las permitidas (GeoPackage, Shapefile .zip, GeoJSON).`); return; }
    if (f.size > TOPE_MB * 1024 * 1024) { setRechazo(`Rechazado: el archivo pesa ${(f.size / 1048576).toFixed(0)} MB y el máximo es ${TOPE_MB} MB.`); return; }
    try {
      const datos = JSON.parse(await f.text());
      const r = revisarGeojson(datos, actualizar ? base?.tipo_geometria : null);
      setArchivo(f); setGj(datos);
      const sugerida = ['id_origen', 'id', 'ID', 'cve', 'clave', 'folio'].find((c) => r.columnas.includes(c));
      if (sugerida) setColId(sugerida);
    } catch {
      setRechazo('Rechazado: el archivo no es un JSON válido o está dañado.');
    }
  };

  const linaje = [ficha.pasos.length ? `Pasos: ${ficha.pasos.join('; ')}.` : '', ficha.notaLinaje.trim() ? `Nota: ${ficha.notaLinaje.trim()}` : ''].filter(Boolean).join(' ');
  const fichaNuevaOk = nom && ficha.titulo.trim().length >= 5 && !tituloRepetido && ficha.custodio && ficha.fuente && ficha.periodicidad && ficha.restriccion && ficha.corte
    && ficha.proposito.trim().length >= 20 && ficha.pasos.length > 0 && ficha.notaLinaje.trim().length >= 15;
  const actualizarOk = base && base.estatus === 'borrador' && revision?.valido && ident?.bien && ficha.motivo && ficha.corte
    && (!pideJustificacion || ficha.justificacion.trim().length >= 30);

  const guardar = async (enviar) => {
    setEstado({ ocupado: true, error: '', hecho: '' });
    try {
      let id = idBase;
      if (actualizar) {
        await guardarCapa({
          id: base.id, n_elementos: revision.n, archivo: archivo.name,
          metadatos_extra: { fecha_corte: ficha.corte, motivo_actualizacion: ficha.motivo, columna_id_origen: colId, justificacion_variacion: pideJustificacion ? ficha.justificacion.trim() : undefined },
        });
      } else {
        id = idNuevo;
        await guardarCapa({
          id, titulo: ficha.titulo.trim(), proposito: ficha.proposito.trim(), tipo_geometria: revision.tipo, srid_origen: 4326,
          responsable: ficha.custodio, id_instrumento: instrumento?.id ?? null, nomenclatura: ficha.nomenclatura, grupos: ficha.grupo || null,
          n_elementos: revision.n, archivo: archivo.name,
          metadatos_extra: {
            custodio: ficha.custodio, fuente_origen: ficha.fuente, linaje, sistema_coordenadas: 'EPSG:4326 — WGS 84', restriccion_uso: ficha.restriccion,
            periodicidad: ficha.periodicidad, fecha_corte: ficha.corte, categoria: nom.categoria, columna_id_origen: colId, documento: doc?.name,
          },
        });
      }
      if (enviar) await enviarCapaARevision(id);
      setEstado({ ocupado: false, error: '', hecho: enviar ? `La capa ${id} quedó enviada a revisión del administrador.` : `La capa ${id} quedó guardada como borrador.` });
      onGuardada?.(id);
    } catch (err) {
      setEstado({ ocupado: false, error: err.message, hecho: '' });
    }
  };

  const verEnMapa = () => {
    const c = actualizar ? base : { id: idNuevo, titulo: ficha.titulo, categoria: nom?.categoria };
    onVistaPrevia?.({ capa: { ...c, geom: GEOM_LEAFLET[revision.tipo] ?? 'polygon', tipo_geometria: revision.tipo, estatus: 'borrador' }, geojson: gj });
    cerrar();
  };

  const pasosNombres = actualizar ? ['Capa', 'Archivo', 'Cambios'] : ['Archivo', 'Ficha', 'Revisión'];
  const idx = actualizar ? paso : paso - 1;

  return (
    <>
      <div className="modal-drawer-overlay" onClick={cerrar} />
      <div className="modal-drawer cc-drawer" role="dialog" aria-modal="true" aria-labelledby="cc-titulo">
        <div className="modal-drawer-header">
          <div>
            <h3 id="cc-titulo" className="cc-titulo">{actualizar ? 'Actualizar una capa' : 'Subir una capa nueva'}</h3>
            <ol className="cc-pasos" aria-label="Avance">
              {pasosNombres.map((n, i) => <li key={n} className={i === idx ? 'cc-paso cc-paso--act' : i < idx ? 'cc-paso cc-paso--ok' : 'cc-paso'} aria-current={i === idx ? 'step' : undefined}>{i + 1}. {n}</li>)}
            </ol>
          </div>
          <button type="button" className="btn-close-drawer" onClick={cerrar} aria-label="Cerrar"><X size={20} /></button>
        </div>

        <div className="modal-drawer-content cc-cuerpo">
          {estado.hecho ? (
            <div className="cc-hecho">
              <CheckCircle2 size={36} aria-hidden="true" />
              <p>{estado.hecho}</p>
              <small>Los elementos geográficos se cargarán a la base cuando el servicio de ingesta esté habilitado; el administrador ya puede revisar la ficha.</small>
              <button type="button" className="btn-base btn-primary" onClick={cerrar}>Listo</button>
            </div>
          ) : (
            <>
              {/* ------------ Actualizar · paso 0: elegir la capa ------------ */}
              {actualizar && paso === 0 && (
                <>
                  <label className="cc-campo">¿Qué capa vas a actualizar?
                    <select className="form-input" value={idBase} onChange={(e) => setIdBase(e.target.value)}>
                      <option value="">Elige una capa…</option>
                      {capas.map((c) => <option key={c.id} value={c.id}>{c.id} · {c.titulo} ({ESTATUS_CAPA[c.estatus] ?? c.estatus})</option>)}
                    </select>
                  </label>
                  {base && base.estatus !== 'borrador' && (
                    <div className="cc-aviso cc-aviso--info">
                      <Lock size={16} aria-hidden="true" />
                      <span>La capa <b>{base.id}</b> está <b>{ESTATUS_CAPA[base.estatus]}</b> y no se puede modificar directamente: así se protege lo que ya fue validado. Pide al administrador que la <b>devuelva a borrador</b> y entonces podrás actualizarla aquí.</span>
                    </div>
                  )}
                  {base && base.estatus === 'borrador' && (
                    <dl className="cc-ficha-fija">
                      <dt>Título</dt><dd>{base.titulo}</dd>
                      <dt>Tipo de geometría</dt><dd>{base.tipo_geometria ?? '—'}</dd>
                      <dt>Elementos actuales</dt><dd>{previo}</dd>
                    </dl>
                  )}
                </>
              )}

              {/* ------------ Archivo ------------ */}
              {((actualizar && paso === 1) || (!actualizar && paso === 1)) && (
                <>
                  <div className="cc-carga">
                    <UploadCloud size={22} aria-hidden="true" />
                    <label className="cc-campo">Archivo de la capa
                      <input type="file" className="form-input" accept=".geojson,.json,.gpkg,.zip" onChange={(e) => leer(e.target.files?.[0])} />
                    </label>
                    <small>Sistema de coordenadas único: <b>EPSG:4326 (WGS 84)</b>. Formatos: GeoPackage (recomendado) y Shapefile .zip — los revisa el servicio de procesos, aún no habilitado — y GeoJSON, que se revisa aquí. Máximo {TOPE_MB} MB.</small>
                  </div>
                  {rechazo && <div className="cc-aviso cc-aviso--error" role="alert"><XCircle size={16} aria-hidden="true" /><span>{rechazo}</span></div>}
                  {revision && (
                    <>
                      <p className={`cc-veredicto ${revision.valido ? 'cc-veredicto--ok' : 'cc-veredicto--mal'}`} role="status">
                        {revision.valido ? <><CheckCircle2 size={16} aria-hidden="true" /> El archivo pasó la revisión.</> : <><XCircle size={16} aria-hidden="true" /> El archivo se rechaza: corrige lo marcado y vuelve a subirlo.</>}
                      </p>
                      <table className="cc-tabla">
                        <tbody>
                          {revision.filas.map((f) => (
                            <tr key={f.que} className={f.bien ? '' : 'cc-mal'}>
                              <th scope="row">{f.que}</th>
                              <td>{f.encontrado}{!f.bien && <small>{f.ayuda}</small>}</td>
                              <td aria-label={f.bien ? 'Correcto' : 'Con error'}>{f.bien ? <CheckCircle2 size={16} aria-hidden="true" /> : <XCircle size={16} aria-hidden="true" />}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {revision.valido && (
                        <>
                          <label className="cc-campo">¿Qué columna identifica a cada elemento?
                            <select className="form-input" value={colId} onChange={(e) => setColId(e.target.value)}>
                              <option value="">Elige una columna…</option>
                              {revision.columnas.map((c) => <option key={c} value={c}>{c}</option>)}
                            </select>
                          </label>
                          {ident && <p className={`cc-veredicto ${ident.bien ? 'cc-veredicto--ok' : 'cc-veredicto--mal'}`}>{ident.bien ? <CheckCircle2 size={16} aria-hidden="true" /> : <XCircle size={16} aria-hidden="true" />} {ident.texto}</p>}
                        </>
                      )}
                    </>
                  )}
                </>
              )}

              {/* ------------ Nueva · ficha desde listas ------------ */}
              {!actualizar && paso === 2 && (
                <>
                  <div className="cc-dos">
                    <label className="cc-campo">Tipo de capa
                      <select className="form-input" value={ficha.nomenclatura} onChange={(e) => setFicha((f) => ({ ...f, nomenclatura: e.target.value, grupo: '' }))}>
                        <option value="">Elige…</option>
                        {[...nomenclaturas.keys()].sort().map((n) => <option key={n} value={n}>{n} ({nomenclaturas.get(n).prefijo})</option>)}
                      </select>
                    </label>
                    <label className="cc-campo">Grupo temático
                      <select className="form-input" value={ficha.grupo} onChange={fijar('grupo')} disabled={!nom}>
                        <option value="">Elige…</option>
                        {nom && [...nom.grupos].map((g) => <option key={g}>{g}</option>)}
                      </select>
                    </label>
                  </div>
                  <dl className="cc-ficha-fija">
                    <dt>Identificador (lo asigna el sistema)</dt><dd>{idNuevo || '—'}</dd>
                    <dt>Instrumento de origen</dt><dd>{instrumento ? `${instrumento.clave} (${instrumento.id})` : nom ? 'Ninguno (mapa base)' : '—'}</dd>
                    <dt>Geometría y elementos (del archivo)</dt><dd>{revision?.tipo} · {revision?.n}</dd>
                    <dt>Sistema de coordenadas</dt><dd>EPSG:4326 — WGS 84</dd>
                  </dl>
                  <label className="cc-campo">Título de la capa
                    <input className="form-input" value={ficha.titulo} onChange={fijar('titulo')} maxLength={120} />
                    {tituloRepetido && <small className="cc-error">Ya existe una capa con ese título.</small>}
                  </label>
                  <div className="cc-dos">
                    <label className="cc-campo">Custodio
                      <select className="form-input" value={ficha.custodio} onChange={fijar('custodio')}><option value="">Elige…</option>{custodios.map((c) => <option key={c}>{c}</option>)}</select>
                    </label>
                    <label className="cc-campo">Fuente de origen
                      <select className="form-input" value={ficha.fuente} onChange={fijar('fuente')}><option value="">Elige…</option>{fuentes.map((c) => <option key={c}>{c}</option>)}</select>
                    </label>
                    <label className="cc-campo">Periodicidad
                      <select className="form-input" value={ficha.periodicidad} onChange={fijar('periodicidad')}><option value="">Elige…</option>{PERIODICIDADES.map((p) => <option key={p}>{p}</option>)}</select>
                    </label>
                    <label className="cc-campo">Fecha de corte de los datos
                      <input type="date" className="form-input" value={ficha.corte} max={new Date().toISOString().slice(0, 10)} onChange={fijar('corte')} />
                    </label>
                  </div>
                  <fieldset className="cc-campo cc-opciones">
                    <legend>Restricción de uso</legend>
                    <label><input type="radio" name="restr" checked={ficha.restriccion === 'pública'} onChange={() => setFicha((f) => ({ ...f, restriccion: 'pública' }))} /> Pública — podrá verse en el geovisor público</label>
                    <label><input type="radio" name="restr" checked={ficha.restriccion === 'interna'} onChange={() => setFicha((f) => ({ ...f, restriccion: 'interna' }))} /> Interna — solo personal con cuenta</label>
                  </fieldset>
                  <label className="cc-campo">Propósito (¿para qué sirve esta capa?)
                    <textarea className="form-input" rows={3} value={ficha.proposito} onChange={fijar('proposito')} maxLength={400} />
                    <small>{ficha.proposito.trim().length}/20 caracteres mínimo</small>
                  </label>
                  <fieldset className="cc-campo cc-opciones">
                    <legend>Linaje: ¿cómo se obtuvo? (marca los que apliquen)</legend>
                    {PASOS_LINAJE.map((p) => (
                      <label key={p}><input type="checkbox" checked={ficha.pasos.includes(p)} onChange={(e) => setFicha((f) => ({ ...f, pasos: e.target.checked ? [...f.pasos, p] : f.pasos.filter((x) => x !== p) }))} /> {p}</label>
                    ))}
                  </fieldset>
                  <label className="cc-campo">Nota de linaje (una o dos frases)
                    <textarea className="form-input" rows={2} value={ficha.notaLinaje} onChange={fijar('notaLinaje')} maxLength={300} />
                    <small>{ficha.notaLinaje.trim().length}/15 caracteres mínimo. «No aplica» no es una respuesta válida.</small>
                  </label>
                  <label className="cc-campo">Ficha técnica en PDF (opcional, hasta 10 MB)
                    <input type="file" accept=".pdf" className="form-input" onChange={(e) => { const f = e.target.files?.[0]; setDoc(f && f.size <= 10 * 1048576 ? f : null); }} />
                  </label>
                </>
              )}

              {/* ------------ Actualizar · paso 2: cambios ------------ */}
              {actualizar && paso === 2 && base && revision && (
                <>
                  <dl className="cc-ficha-fija">
                    <dt>Capa</dt><dd>{base.id} · {base.titulo}</dd>
                    <dt>Elementos</dt><dd>{previo} antes → {revision.n} ahora ({revision.n - previo >= 0 ? '+' : ''}{revision.n - previo})</dd>
                    <dt>Variación</dt><dd>{(variacion * 100).toFixed(0)} %</dd>
                  </dl>
                  <div className="cc-dos">
                    <label className="cc-campo">Motivo de la actualización
                      <select className="form-input" value={ficha.motivo} onChange={fijar('motivo')}><option value="">Elige…</option>{MOTIVOS.map((m) => <option key={m}>{m}</option>)}</select>
                    </label>
                    <label className="cc-campo">Nueva fecha de corte
                      <input type="date" className="form-input" value={ficha.corte} max={new Date().toISOString().slice(0, 10)} onChange={fijar('corte')} />
                    </label>
                  </div>
                  {pideJustificacion && (
                    <label className="cc-campo">Justificación del cambio
                      <div className="cc-aviso cc-aviso--info"><AlertTriangle size={16} aria-hidden="true" /><span>La capa cambia {(variacion * 100).toFixed(0)} % (más del 20 %). Explica el motivo; el administrador lo revisará.</span></div>
                      <textarea className="form-input" rows={3} value={ficha.justificacion} onChange={fijar('justificacion')} maxLength={600} />
                      <small>{ficha.justificacion.trim().length}/30 caracteres mínimo</small>
                    </label>
                  )}
                  <p className="cc-nota"><Lock size={14} aria-hidden="true" /> La ficha (título, custodio, fuente, linaje, restricción de uso) se conserva como está y no se edita aquí.</p>
                </>
              )}

              {/* ------------ Nueva · paso 3: revisión ------------ */}
              {!actualizar && paso === 3 && (
                <>
                  <dl className="cc-ficha-fija">
                    <dt>Identificador</dt><dd>{idNuevo}</dd>
                    <dt>Título</dt><dd>{ficha.titulo}</dd>
                    <dt>Geometría · elementos</dt><dd>{revision?.tipo} · {revision?.n}</dd>
                    <dt>Custodio</dt><dd>{ficha.custodio}</dd>
                    <dt>Fuente</dt><dd>{ficha.fuente}</dd>
                    <dt>Restricción de uso</dt><dd>{ficha.restriccion}</dd>
                    <dt>Corte · periodicidad</dt><dd>{ficha.corte} · {ficha.periodicidad}</dd>
                  </dl>
                  <p className="cc-nota">«Guardar borrador» te deja seguir editando. «Enviar a revisión» la manda al administrador y deja de ser editable por ti.</p>
                </>
              )}

              {estado.error && <div className="cc-aviso cc-aviso--error" role="alert"><XCircle size={16} aria-hidden="true" /><span>{estado.error}</span></div>}
            </>
          )}
        </div>

        {!estado.hecho && (
          <div className="modal-drawer-footer cc-pie">
            <button type="button" className="btn-base btn-secondary" onClick={() => (paso > (actualizar ? 0 : 1) ? setPaso(paso - 1) : cerrar())}><ArrowLeft size={14} /> {paso > (actualizar ? 0 : 1) ? 'Atrás' : 'Cancelar'}</button>
            {revision?.valido && ident?.bien && <button type="button" className="btn-base btn-secondary" onClick={verEnMapa}><MapaIcono size={14} /> Ver en el mapa</button>}
            {((actualizar && paso < 2) || (!actualizar && paso < 3)) ? (
              <button
                type="button"
                className="btn-base btn-primary"
                disabled={(actualizar && paso === 0 && !(base && base.estatus === 'borrador')) || (paso === 1 && !(revision?.valido && ident?.bien)) || (!actualizar && paso === 2 && !fichaNuevaOk)}
                onClick={() => setPaso(paso + 1)}
              >Siguiente <ArrowRight size={14} /></button>
            ) : (
              <>
                <button type="button" className="btn-base btn-secondary" disabled={estado.ocupado || !(actualizar ? actualizarOk : fichaNuevaOk)} onClick={() => guardar(false)}><Save size={14} /> Guardar borrador</button>
                <button type="button" className="btn-base btn-primary" disabled={estado.ocupado || !(actualizar ? actualizarOk : fichaNuevaOk)} aria-busy={estado.ocupado} onClick={() => guardar(true)}><Send size={14} /> {estado.ocupado ? 'Enviando…' : 'Enviar a revisión'}</button>
              </>
            )}
          </div>
        )}
      </div>
    </>
  );
}
