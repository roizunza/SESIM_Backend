import { useCallback, useEffect, useMemo, useState } from 'react';
import { GeoJSON } from 'react-leaflet';
import L from 'leaflet';
import { Send, Pencil, Loader2 } from 'lucide-react';
import CapturistaSidebar from './CapturistaSidebar';
import MedicionModal from './MedicionModal';
import CapaCapturaModal from './CapaCapturaModal';
import MapaCaptura from './MapaCaptura';
import DetalleMedicion from '../comun/DetalleMedicion';
import { useCatalogoOperativo } from '../comun/useCatalogoOperativo';
import RechazosPanel from '../comun/RechazosPanel';
import RecorridoGeovisor, { recorridoVisto, marcarRecorrido } from '../../geovisor/RecorridoGeovisor';
import { pendientesRechazo } from '../../../lib/sesim/catalogoApi';
import { cargarArbolCapas } from '../../../lib/sesim/capas';
import { CONFIG_INICIAL } from '../../../lib/sesim/estiloCapa';
import PanelFab from '../comun/PanelFab';
import { usePanelLateral } from '../../../lib/sesim/usePanelLateral';
import { useSesion } from '../../../lib/sesim/sesion';
import { useMediciones, enviarMedicionApi } from '../../../lib/sesim/medicionesApi';
import '../comun/Comun.css';

/**
 * Perfil CAPTURISTA (Tabla 3). Trabaja en dos frentes, de más a menos frecuente:
 *
 *  1. CAPAS: sube capas nuevas y actualiza las suyas mientras están en borrador (api.fn_guardar_capa) y las envía a
 *     revisión (api.fn_enviar_capa_revision). Todo desde listas; el archivo se revisa en el acto (EPSG:4326 único).
 *  2. MEDICIONES: captura el valor de un indicador aprobado → evidencia → envío a revisión; si se devuelve, corrige
 *     y reenvía (plazo de 10 días hábiles).
 *
 * No da de alta indicadores ni instrumentos (atribución del Administrador).
 * El mapa es propio del perfil (MapaCaptura): simbología en cristal como el geovisor público, acercar/alejar,
 * medir, mapa claro/satélite y guía.
 */

/** Guía de primera visita (mismo recorrido con foco que el geovisor). Cada `sel` es una zona real; si no está a la vista el paso se omite. */
const PASOS_GUIA = [
  { id: 'subir', sel: '.cap-subir', titulo: 'Sube una capa nueva', texto: 'Es lo que más harás. Eliges el archivo, el sistema lo revisa al instante y completas la ficha eligiendo de listas.', items: [
    { marca: '1', texto: 'Un solo sistema de coordenadas: EPSG:4326 (WGS 84).' },
    { marca: '2', texto: 'Si algo no cumple, se rechaza y te dice qué corregir.' },
    { marca: '3', texto: 'Guarda como borrador o envía a revisión.' }] },
  { id: 'actualizar', sel: '.cap-actualizar', titulo: 'Actualiza una capa', texto: 'Para una capa tuya en borrador: subes el archivo nuevo, eliges el motivo y la fecha de corte. Si cambia 20 % o más, explicas por qué. Una capa ya validada la devuelve primero el administrador.' },
  { id: 'abrir-panel', sel: '.cap-toggle', selMovil: '.panel-fab', titulo: 'Abre o pliega tu panel', texto: 'Muestra tu panel completo o lo deja como una barra de íconos para tener más mapa.' },
  { id: 'pestanas', sel: '.cap-pestanas', titulo: 'Dos pestañas', texto: '«Explorar» sirve para buscar capas y verlas en el mapa. «Mi mesa de trabajo» reúne lo que tienes pendiente: lo devuelto con plazo, tus borradores y lo que está en revisión.' },
  { id: 'nuevo-med', sel: '.cap-nuevo-med, .cap-riel__btn.cap-nuevo', titulo: 'Captura una medición', texto: 'Elige el indicador aprobado, el periodo y el municipio, registra el valor y adjunta la evidencia (PDF, JPG o PNG de hasta 10 MB).' },
  { id: 'herramientas', sel: '.mc-herramientas', titulo: 'Herramientas del mapa', texto: 'Acerca, aleja, mide distancias, cambia entre mapa claro y satélite, o vuelve a abrir esta guía.' },
  { id: 'simbologia', sel: '.leyenda-flotante', titulo: 'Simbología', texto: 'Aparece cuando enciendes capas en «Explorar». Puedes arrastrarla y apagar la simbología de una capa o de una categoría completa.' },
  { id: 'bitacora', sel: '.cap-bitacora', titulo: 'Tu bitácora', texto: 'Cada cosa que haces queda registrada: quién, qué y cuándo.' },
  { id: 'guia', sel: '.cap-guia-btn', titulo: 'Vuelve cuando quieras', texto: 'Con el botón «?» abres de nuevo esta guía.' },
];

const estiloVistaPrevia = { color: '#9F2241', weight: 2, fillColor: '#9F2241', fillOpacity: 0.25 };

const CapturistaLayout = () => {
  const sesion = useSesion();
  const api = useMediciones();
  const { catalogo, error } = useCatalogoOperativo();
  const [panelAbierto, setPanelAbierto, esMovil] = usePanelLateral();
  const [modal, setModal] = useState({ abierto: false, id: null });
  const [modalCapa, setModalCapa] = useState(null); // { modo, id, n }
  const [vistaPrevia, setVistaPrevia] = useState(null);
  const [mapa, setMapa] = useState(null);
  const [seleccion, setSeleccion] = useState(null);
  const [errorAccion, setErrorAccion] = useState('');
  const [rechazos, setRechazos] = useState(false);
  const [rechazosCapas, setRechazosCapas] = useState([]);
  const [enviandoId, setEnviandoId] = useState(null);
  const [arbol, setArbol] = useState(null);
  const [errorArbol, setErrorArbol] = useState('');
  const [version, setVersion] = useState(0);
  const [activas, setActivas] = useState(() => new Set());
  const [configPorCapa, setConfigPorCapa] = useState({});
  const claveGuia = `sesim.capturista.recorrido.v2.${sesion?.id ?? 'anon'}`;
  const [guia, setGuia] = useState(() => !recorridoVisto(claveGuia));

  const cargarRechazos = useCallback(() => {
    pendientesRechazo().then((r) => { if (Array.isArray(r)) setRechazosCapas(r); }).catch(() => {});
  }, []);
  useEffect(() => { cargarRechazos(); }, [cargarRechazos]);

  // La RLS ya limita al capturista: ve lo validado/publicado y SUS borradores.
  useEffect(() => {
    let vivo = true;
    cargarArbolCapas({ incluirBorrador: true })
      .then((a) => { if (vivo) { setArbol(a); setErrorArbol(''); } })
      .catch((e) => { if (vivo) setErrorArbol(e.message); });
    return () => { vivo = false; };
  }, [version]);

  const capasTodas = useMemo(() => (arbol ? [...arbol.capasPorId.values()] : []), [arbol]);
  const capasMias = useMemo(() => capasTodas.filter((c) => ['borrador', 'revision'].includes(c.estatus)), [capasTodas]);
  const catalogoCapas = useMemo(() => (catalogo ? { ...catalogo, capa: capasTodas } : null), [catalogo, capasTodas]);
  const capasEnMapa = useMemo(() => [...activas].map((id) => arbol?.capasPorId.get(id)).filter(Boolean), [activas, arbol]);
  const configDe = useCallback((id) => configPorCapa[id] ?? CONFIG_INICIAL, [configPorCapa]);

  const alternarCapa = (id) => setActivas((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  const alternarSimbologia = (id) => setConfigPorCapa((p) => ({ ...p, [id]: { ...configDe(id), simbologia: !configDe(id).simbologia } }));
  const alternarCategoria = (idCat, visible) => setConfigPorCapa((p) => {
    const n = { ...p };
    capasEnMapa.forEach((c) => { if (c.categoria === idCat) n[c.id] = { ...(p[c.id] ?? CONFIG_INICIAL), simbologia: visible }; });
    return n;
  });

  // La RLS ya limita al capturista a SUS mediciones.
  const mias = api.mediciones;
  const periodosPorId = useMemo(() => new Map(api.periodos.map((p) => [p.id, p])), [api.periodos]);
  const seleccionada = mias.find((m) => m.id === seleccion);
  const tieneEvidencia = (id) => api.evidencias.some((e) => e.id_medicion === id && e.vigente);

  const abrir = (id) => {
    setErrorAccion('');
    setSeleccion(id);
    if (esMovil) setPanelAbierto(false);
  };

  const enviar = async (id) => {
    setErrorAccion('');
    setEnviandoId(id);
    try {
      await enviarMedicionApi(id);
    } catch (err) {
      setErrorAccion(err.message);
    } finally {
      setEnviandoId(null);
    }
  };

  const abrirCapa = (modo, id) => {
    setModalCapa({ modo, id: typeof id === 'string' ? id : null, n: Date.now() });
    if (esMovil) setPanelAbierto(false);
  };

  const mostrarVistaPrevia = ({ capa, geojson }) => {
    setVistaPrevia({ capa, geojson });
    try { mapa?.flyToBounds(L.geoJSON(geojson).getBounds(), { padding: [60, 60], duration: 1 }); } catch { /* sin geometría */ }
  };

  const cerrarGuia = () => { marcarRecorrido(claveGuia); setGuia(false); };

  return (
    <div className={`dashboard-fullscreen-container cap-contenedor${!esMovil && !panelAbierto ? ' cap-contenedor--riel' : ''}`}>
      <MapaCaptura
        capas={capasEnMapa}
        configDe={configDe}
        onAlternarCapa={alternarSimbologia}
        onAlternarCategoria={alternarCategoria}
        resaltarUnidad={seleccionada?.id_unidad}
        onMapa={setMapa}
        onGuia={() => setGuia(true)}
        panelAbierto={panelAbierto && !esMovil}
      >
        {vistaPrevia && (
          <GeoJSON
            key={vistaPrevia.capa.id + (vistaPrevia.geojson.features?.length ?? 0)}
            data={vistaPrevia.geojson}
            style={estiloVistaPrevia}
            pointToLayer={(f, ll) => L.circleMarker(ll, { radius: 5, ...estiloVistaPrevia, fillOpacity: 0.7 })}
          />
        )}
      </MapaCaptura>

      <PanelFab abierto={panelAbierto} esMovil={esMovil} onAbrir={() => setPanelAbierto(true)} onCerrar={() => setPanelAbierto(false)} etiqueta="Mi panel" />

      <div className="floating-sidebar-wrapper">
        <CapturistaSidebar
          abierto={panelAbierto}
          setAbierto={setPanelAbierto}
          esMovil={esMovil}
          sesion={sesion}
          catalogo={catalogo}
          mediciones={mias}
          periodosPorId={periodosPorId}
          evidencias={api.evidencias}
          seleccion={seleccion}
          rechazosCapas={rechazosCapas}
          capasMias={capasMias}
          arbol={arbol}
          activas={activas}
          onAlternarCapa={alternarCapa}
          onSubirCapa={() => abrirCapa('nueva')}
          onActualizarCapa={(id) => abrirCapa('actualizar', id)}
          onNueva={() => { setModal({ abierto: true, id: null }); if (esMovil) setPanelAbierto(false); }}
          onSeleccionar={abrir}
          onRechazos={() => { setRechazos(true); if (esMovil) setPanelAbierto(false); }}
          onGuia={() => { setGuia(true); }}
        />
      </div>

      {rechazos && <RechazosPanel sesion={sesion} onClose={() => { setRechazos(false); cargarRechazos(); }} onCambio={cargarRechazos} />}

      {vistaPrevia && (
        <button type="button" className="btn-base btn-secondary cap-quitar-previa" onClick={() => setVistaPrevia(null)}>Quitar vista previa de {vistaPrevia.capa.id}</button>
      )}

      {(error || errorArbol) && <div className="aviso aviso-error cap-aviso-flotante">No se pudo cargar el catálogo: {error || errorArbol}</div>}
      {api.error && (
        <div className="aviso aviso-error cap-aviso-flotante cap-aviso-flotante--2">
          No se pudieron leer sus mediciones: {api.error}
          <button type="button" className="btn-base btn-secondary" style={{ width: 'auto', height: 28 }} onClick={() => api.recargar()}>Reintentar</button>
        </div>
      )}

      {catalogoCapas && modalCapa && (
        <CapaCapturaModal
          key={modalCapa.n}
          abierto
          modo={modalCapa.modo}
          capaInicial={modalCapa.id ? capasTodas.find((c) => c.id === modalCapa.id) ?? null : null}
          catalogo={catalogoCapas}
          onClose={() => setModalCapa(null)}
          onGuardada={() => { setVersion((v) => v + 1); cargarRechazos(); }}
          onVistaPrevia={mostrarVistaPrevia}
        />
      )}

      {catalogo && seleccionada && !modal.abierto && (
        <DetalleMedicion
          idMedicion={seleccionada.id}
          catalogo={catalogo}
          real
          onClose={() => setSeleccion(null)}
          pie={
            ['borrador', 'rechazado'].includes(seleccionada.estado) ? (
              <>
                {errorAccion && <div className="aviso aviso-error">{errorAccion}</div>}
                <div className="fila-botones">
                  <button type="button" className="btn-base btn-secondary" onClick={() => setModal({ abierto: true, id: seleccionada.id })}><Pencil size={14} /> Editar</button>
                  <button
                    type="button"
                    className="btn-base btn-primary"
                    disabled={enviandoId === seleccionada.id || !tieneEvidencia(seleccionada.id)}
                    aria-busy={enviandoId === seleccionada.id}
                    title={tieneEvidencia(seleccionada.id) ? '' : 'Adjunte una evidencia (Editar) para poder enviarla'}
                    onClick={() => enviar(seleccionada.id)}
                  >
                    {enviandoId === seleccionada.id ? <Loader2 size={14} className="girando" /> : <Send size={14} />} {enviandoId === seleccionada.id ? 'Enviando…' : seleccionada.estado === 'rechazado' ? 'Reenviar' : 'Enviar a revisión'}
                  </button>
                </div>
              </>
            ) : null
          }
        />
      )}

      {catalogo && (
        <MedicionModal
          abierto={modal.abierto}
          idMedicion={modal.id}
          sesion={sesion}
          catalogo={catalogo}
          onClose={() => setModal({ abierto: false, id: null })}
          onGuardada={(id) => setSeleccion(id)}
        />
      )}

      <RecorridoGeovisor
        abierto={guia}
        onCerrar={cerrarGuia}
        pasos={PASOS_GUIA}
        titulo="Guía del capturista"
        etiqueta="Guía del capturista"
        encabezado="Sube capas, corrige y envía tu trabajo"
        intro="Te mostramos dónde subir y actualizar capas, dónde ver lo que te devolvieron y cómo capturar mediciones, en {total} pasos de menos de un minuto."
        recordatorio={<>Siempre podrás volver con el botón <b>?</b> de tu panel o del mapa.</>}
      />
    </div>
  );
};

export default CapturistaLayout;
