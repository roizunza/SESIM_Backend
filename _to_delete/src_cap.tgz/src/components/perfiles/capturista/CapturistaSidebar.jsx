import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Plus, History, LogOut, CircleHelp, CornerUpLeft, PencilLine, Hourglass, ClipboardList, PanelLeftOpen, PanelLeftClose,
  ShieldCheck, BadgeCheck, Paperclip, Layers, Compass, Briefcase, UploadCloud, RefreshCw, Search, ChevronRight, ChartColumn,
} from 'lucide-react';
import { cerrarSesion } from '../../../lib/sesim/sesion';
import { ESTATUS_CAPA } from '../../../lib/sesim/capas';
import { nombreUnidad } from '../comun/formato';
import './Capturista.css';

/**
 * Panel del Capturista · mismo patrón de dos pestañas que el geovisor público.
 *
 *  · «Explorar»: qué capas existen y cuáles ver en el mapa (interruptor por capa).
 *  · «Mi mesa de trabajo»: lo que hay que hacer, en orden de urgencia: capas y mediciones devueltas con plazo,
 *    borradores, en revisión y aprobadas.
 *  · Acciones, de más a menos frecuentes: Subir capa nueva · Actualizar capa · Capturar medición.
 *
 * El ESTADO no se distingue por color (el semáforo es de los indicadores): cada estado tiene su ícono y su
 * texto, y la urgencia se expresa con el ORDEN (lo devuelto va primero).
 */
const GRUPOS_ACTIVOS = [
  { estado: 'rechazado', titulo: 'Devueltas · por corregir', Icono: CornerUpLeft, marca: 'urgente', etiqueta: 'Devuelta', nota: 'Con comentario del administrador' },
  { estado: 'borrador', titulo: 'Borradores', Icono: PencilLine, marca: 'borrador', etiqueta: 'Borrador', nota: 'Aún no enviadas' },
  { estado: 'revision', titulo: 'En revisión', Icono: Hourglass, marca: 'espera', etiqueta: 'En revisión', nota: 'Esperando validación' },
];
const GRUPOS_FIN = [
  { estado: 'vigente_admin', titulo: 'Aprobadas · validadas', Icono: ShieldCheck, marca: 'firme', etiqueta: 'Validada', nota: 'Aprobadas para uso interno' },
  { estado: 'vigente_publico', titulo: 'Aprobadas · publicadas', Icono: BadgeCheck, marca: 'firme', etiqueta: 'Publicada', nota: 'Aprobadas y visibles al público' },
];

function ItemMedicion({ m, grupo, periodosPorId, unidadesPorId, activo, sinEvidencia, onSeleccionar }) {
  const { Icono } = grupo;
  return (
    <button type="button" className={`cap-item${activo ? ' cap-item--activo' : ''}`} onClick={() => onSeleccionar(m.id)} aria-current={activo ? 'true' : undefined}>
      <span className={`cap-marca cap-marca--${grupo.marca}`} aria-hidden="true"><Icono size={16} /></span>
      <span className="cap-item__texto">
        <strong>{m.id_indicador} · {periodosPorId.get(m.id_periodo)?.etiqueta ?? '—'}</strong>
        <span>{nombreUnidad(unidadesPorId, m.id_unidad)}</span>
        <span className="cap-item__estado">
          {grupo.etiqueta}
          {sinEvidencia && <span className="cap-item__alerta"><Paperclip size={12} aria-hidden="true" /> Falta evidencia</span>}
        </span>
      </span>
    </button>
  );
}

/** Pestaña «Explorar»: buscar capas y encenderlas en el mapa. */
function Explorar({ arbol, activas, onAlternarCapa }) {
  const [q, setQ] = useState('');
  const [abiertos, setAbiertos] = useState(() => new Set());
  const consulta = q.trim().toLowerCase();
  const coincide = (c) => !consulta || c.id.toLowerCase().includes(consulta) || c.titulo.toLowerCase().includes(consulta);
  if (!arbol) return <p className="cap-vacio">Cargando el catálogo de capas…</p>;
  const alternar = (id) => setAbiertos((s) => { const n = new Set(s); if (n.has(id)) n.delete(id); else n.add(id); return n; });
  return (
    <div className="cap-explorar">
      <label className="cap-buscador">
        <Search size={16} aria-hidden="true" />
        <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar capa por nombre o clave" aria-label="Buscar capa por nombre o clave" />
      </label>
      {arbol.categorias.map((cat) => {
        const grupos = cat.grupos.map((g) => ({ ...g, capas: g.capas.filter(coincide) })).filter((g) => g.capas.length);
        if (!grupos.length) return null;
        return (
          <section key={cat.id} className="cap-cat">
            <h3 className="cap-cat__tit">{cat.etiqueta}</h3>
            {grupos.map((g) => {
              const abierto = consulta ? true : abiertos.has(g.id);
              const nOn = g.capas.filter((c) => activas.has(c.id)).length;
              return (
                <div key={g.id} className="cap-gr">
                  <button type="button" className="cap-gr__cab" aria-expanded={abierto} onClick={() => alternar(g.id)}>
                    <ChevronRight size={15} aria-hidden="true" style={{ transform: abierto ? 'rotate(90deg)' : 'none' }} />
                    <span>{g.etiqueta}</span>
                    <span className="cap-gr__n">{nOn > 0 ? `${nOn}/` : ''}{g.capas.length}</span>
                  </button>
                  {abierto && g.capas.map((c) => (
                    <label key={c.id} className="cap-capa">
                      <input type="checkbox" role="switch" checked={activas.has(c.id)} onChange={() => onAlternarCapa(c.id)} />
                      <span className="cap-capa__txt">
                        <strong>{c.titulo}</strong>
                        <small>{c.id}{c.estatus !== 'vigente_publico' && <span className="cap-capa__est"> · {ESTATUS_CAPA[c.estatus] ?? c.estatus}</span>}</small>
                      </span>
                    </label>
                  ))}
                </div>
              );
            })}
          </section>
        );
      })}
    </div>
  );
}

export default function CapturistaSidebar({
  abierto, setAbierto, esMovil, sesion, catalogo, mediciones, periodosPorId, evidencias = [], seleccion,
  rechazosCapas = [], capasMias = [], arbol, activas, onAlternarCapa,
  onSubirCapa, onActualizarCapa, onNueva, onSeleccionar, onRechazos, onGuia, pestanaInicial = 'explorar',
}) {
  const navigate = useNavigate();
  const [pestana, setPestana] = useState(pestanaInicial);

  const porEstado = useMemo(() => {
    const mapa = new Map();
    mediciones.forEach((m) => mapa.set(m.estado, [...(mapa.get(m.estado) ?? []), m]));
    return mapa;
  }, [mediciones]);
  const conEvidencia = useMemo(() => new Set(evidencias.filter((e) => e.vigente).map((e) => e.id_medicion)), [evidencias]);
  const capasBorrador = capasMias.filter((c) => c.estatus === 'borrador');
  const capasRevision = capasMias.filter((c) => c.estatus === 'revision');

  const nDevueltas = porEstado.get('rechazado')?.length ?? 0;
  const nBorradores = porEstado.get('borrador')?.length ?? 0;
  const nAtender = nDevueltas + nBorradores + rechazosCapas.length + capasBorrador.length;
  const nRevision = (porEstado.get('revision')?.length ?? 0) + capasRevision.length;
  const nAprobadas = (porEstado.get('vigente_admin')?.length ?? 0) + (porEstado.get('vigente_publico')?.length ?? 0);
  const unidades = catalogo?.unidades;
  const salir = () => { cerrarSesion(); navigate('/'); };

  if (esMovil && !abierto) return null;

  /* ---------- Riel (escritorio, plegado) ---------- */
  if (!esMovil && !abierto) {
    return (
      <aside className="cap-barra cap-barra--riel" aria-label="Panel del capturista (plegado)">
        <span className="cap-insignia" aria-hidden="true"><ClipboardList size={24} /></span>
        <button type="button" className="cap-riel__btn cap-riel__btn--activo cap-subir" onClick={onSubirCapa} disabled={!catalogo} title="Subir capa nueva" aria-label="Subir capa nueva"><UploadCloud size={20} /></button>
        <button type="button" className="cap-riel__btn cap-actualizar" onClick={onActualizarCapa} disabled={!catalogo} title="Actualizar capa" aria-label="Actualizar capa"><RefreshCw size={20} /></button>
        <button type="button" className="cap-riel__btn cap-nuevo" onClick={onNueva} disabled={!catalogo} title="Capturar medición" aria-label="Capturar medición"><Plus size={20} /></button>
        <button type="button" className="cap-riel__btn cap-toggle" onClick={() => setAbierto(true)} title="Abrir mi panel" aria-label="Abrir mi panel"><PanelLeftOpen size={20} /></button>
        <div className="cap-pestanas cap-pestanas--riel">
          <button type="button" className="cap-riel__btn" onClick={() => { setPestana('explorar'); setAbierto(true); }} title="Explorar capas" aria-label="Explorar capas"><Compass size={20} /></button>
          <button type="button" className="cap-riel__btn" onClick={() => { setPestana('mesa'); setAbierto(true); }} title={`Mi mesa de trabajo · por atender: ${nAtender}`} aria-label={`Mi mesa de trabajo, por atender: ${nAtender}`}>
            <Briefcase size={20} />{nAtender > 0 && <span className="cap-riel__n">{nAtender}</span>}
          </button>
        </div>
        <span className="cap-riel__sep" />
        <button type="button" className="cap-riel__btn cap-bitacora" onClick={() => navigate('/bitacora')} title="Mi bitácora" aria-label="Mi bitácora"><History size={20} /></button>
        <button type="button" className="cap-riel__btn cap-guia-btn" onClick={onGuia} title="Guía del capturista" aria-label="Guía del capturista"><CircleHelp size={20} /></button>
        <button type="button" className="cap-riel__btn" onClick={salir} title="Cerrar sesión" aria-label="Cerrar sesión"><LogOut size={20} /></button>
      </aside>
    );
  }

  /* ---------- Panel abierto ---------- */
  return (
    <aside className="cap-barra cap-barra--abierta" aria-label="Panel del capturista">
      <header className="cap-cab">
        <div className="cap-cab__fila">
          <span className="cap-insignia" aria-hidden="true"><ClipboardList size={24} /></span>
          <span className="cap-cab__id">
            <span className="cap-rol">Capturista</span>
            <strong className="cap-nombre">{sesion?.nombre || 'Sin nombre registrado'}</strong>
          </span>
          <button type="button" className="cap-icono cap-toggle" onClick={() => setAbierto(false)} title={esMovil ? 'Cerrar panel' : 'Plegar panel'} aria-label={esMovil ? 'Cerrar panel' : 'Plegar panel'}><PanelLeftClose size={20} /></button>
        </div>
        <span className="cap-correo">{sesion?.correo}</span>
      </header>

      <div className="cap-accion cap-acciones">
        <button type="button" className="cap-nuevo cap-subir" onClick={onSubirCapa} disabled={!catalogo}><span className="cap-nuevo__ico" aria-hidden="true"><UploadCloud size={18} /></span> Subir capa nueva</button>
        <div className="cap-acciones__dos">
          <button type="button" className="cap-secundaria cap-actualizar" onClick={onActualizarCapa} disabled={!catalogo}><RefreshCw size={15} aria-hidden="true" /> Actualizar capa</button>
          <button type="button" className="cap-secundaria cap-nuevo-med" onClick={onNueva} disabled={!catalogo}><ChartColumn size={15} aria-hidden="true" /> Capturar medición</button>
        </div>
      </div>

      <div className="cap-cola">
        <div className="cap-pestanas cap-pestanas--carpeta" role="tablist" aria-label="Panel de trabajo">
          <button type="button" role="tab" aria-selected={pestana === 'explorar'} className={`cap-pestana${pestana === 'explorar' ? ' cap-pestana--activa' : ''}`} onClick={() => setPestana('explorar')}>
            <Compass size={16} aria-hidden="true" className="cap-pestana__ico" /> Explorar
          </button>
          <button type="button" role="tab" aria-selected={pestana === 'mesa'} className={`cap-pestana${pestana === 'mesa' ? ' cap-pestana--activa' : ''}`} onClick={() => setPestana('mesa')}>
            <Briefcase size={16} aria-hidden="true" className="cap-pestana__ico" /> Mi mesa de trabajo {nAtender > 0 && <span className="cap-pestana__n" aria-label={`${nAtender} por atender`}>{nAtender}</span>}
          </button>
        </div>

        <div className={`cap-carpeta cap-carpeta--${pestana}`} role="tabpanel">
          {pestana === 'explorar' && <Explorar arbol={arbol} activas={activas} onAlternarCapa={onAlternarCapa} />}

          {pestana === 'mesa' && (
            <>
              <dl className="cap-resumen" aria-label="Resumen">
                <div><dt>Por atender</dt><dd>{nAtender}</dd></div>
                <div><dt>En revisión</dt><dd>{nRevision}</dd></div>
                <div><dt>Aprobadas</dt><dd>{nAprobadas}</dd></div>
              </dl>

              <h2 className="cap-seccion"><Layers size={15} aria-hidden="true" /> Mis capas</h2>
              {rechazosCapas.length > 0 && (
                <section className="cap-grupo cap-grupo--urgente">
                  <h3 className="cap-grupo__tit"><span>Devueltas · con plazo</span><span className="cap-grupo__n">{rechazosCapas.length}</span></h3>
                  <p className="cap-grupo__nota">Cada una da <strong>10 días hábiles</strong> para retomarla o quitarla de tu lista.</p>
                  {rechazosCapas.map((r) => (
                    <button type="button" key={r.id_dictamen} className="cap-item" onClick={onRechazos}>
                      <span className="cap-marca cap-marca--urgente" aria-hidden="true"><CornerUpLeft size={16} /></span>
                      <span className="cap-item__texto">
                        <strong>{r.objeto_id}</strong>
                        <span>{r.objeto_tipo === 'capa' ? 'Capa' : r.objeto_tipo === 'medicion' ? 'Medición' : 'Instrumento'} · {r.titulo}</span>
                        <span className="cap-item__estado">
                          {r.estado === 'retomada' ? 'Retomada: falta reenviar' : 'Pendiente de decidir'}
                          {r.dias_habiles_restantes != null && <span className="cap-item__alerta">{r.dias_habiles_restantes} {r.dias_habiles_restantes === 1 ? 'día hábil' : 'días hábiles'}</span>}
                        </span>
                      </span>
                    </button>
                  ))}
                </section>
              )}
              <section className="cap-grupo">
                <h3 className="cap-grupo__tit"><span>Borradores</span><span className="cap-grupo__n">{capasBorrador.length}</span></h3>
                <p className="cap-grupo__nota">{capasBorrador.length === 0 ? 'Ninguna por ahora' : 'Aún no enviadas'}</p>
                {capasBorrador.map((c) => (
                  <button type="button" key={c.id} className="cap-item" onClick={() => onActualizarCapa(c.id)}>
                    <span className="cap-marca cap-marca--borrador" aria-hidden="true"><PencilLine size={16} /></span>
                    <span className="cap-item__texto"><strong>{c.id}</strong><span>{c.titulo}</span><span className="cap-item__estado">Borrador · continuar</span></span>
                  </button>
                ))}
              </section>
              <section className="cap-grupo">
                <h3 className="cap-grupo__tit"><span>En revisión</span><span className="cap-grupo__n">{capasRevision.length}</span></h3>
                <p className="cap-grupo__nota">{capasRevision.length === 0 ? 'Ninguna por ahora' : 'Esperando validación'}</p>
                {capasRevision.map((c) => (
                  <div key={c.id} className="cap-item cap-item--fijo">
                    <span className="cap-marca cap-marca--espera" aria-hidden="true"><Hourglass size={16} /></span>
                    <span className="cap-item__texto"><strong>{c.id}</strong><span>{c.titulo}</span><span className="cap-item__estado">En revisión</span></span>
                  </div>
                ))}
              </section>

              <h2 className="cap-seccion"><ChartColumn size={15} aria-hidden="true" /> Mis mediciones de indicadores</h2>
              {mediciones.length === 0 && <p className="cap-vacio">Aún no has capturado datos de indicadores.</p>}
              {[...GRUPOS_ACTIVOS, ...GRUPOS_FIN].map((g) => {
                const lista = porEstado.get(g.estado) ?? [];
                if (lista.length === 0 && mediciones.length === 0) return null;
                return (
                  <section key={g.estado} className={`cap-grupo${g.marca === 'urgente' && lista.length > 0 ? ' cap-grupo--urgente' : ''}`}>
                    <h3 className="cap-grupo__tit"><span>{g.titulo}</span><span className="cap-grupo__n">{lista.length}</span></h3>
                    <p className="cap-grupo__nota">{lista.length === 0 ? 'Ninguna por ahora' : g.nota}</p>
                    {lista.map((m) => (
                      <ItemMedicion key={m.id} m={m} grupo={g} periodosPorId={periodosPorId} unidadesPorId={unidades} activo={seleccion === m.id} sinEvidencia={m.estado === 'borrador' && !conEvidencia.has(m.id)} onSeleccionar={onSeleccionar} />
                    ))}
                  </section>
                );
              })}
              <button type="button" className="cap-ver-todo" onClick={onRechazos}>Ver devoluciones con plazo</button>
            </>
          )}
        </div>
      </div>

      <footer className="cap-pie">
        <button type="button" className="cap-enlace cap-bitacora" onClick={() => navigate('/bitacora')}><span className="cap-enlace__ico" aria-hidden="true"><History size={17} /></span> Mi bitácora</button>
        <button type="button" className="cap-enlace cap-guia-btn" onClick={onGuia}><span className="cap-enlace__ico" aria-hidden="true"><CircleHelp size={17} /></span> Guía del capturista</button>
        <button type="button" className="cap-enlace" onClick={salir}><span className="cap-enlace__ico" aria-hidden="true"><LogOut size={17} /></span> Cerrar sesión</button>
      </footer>
    </aside>
  );
}
